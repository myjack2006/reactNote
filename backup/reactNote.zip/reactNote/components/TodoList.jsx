import React, {Component, PropTypes} from 'react';
import Todo from './Todo.jsx';

export default class TotoList extends Component {
    render() {
		return (
	    <ul>
		    
		</ul>
		);
	}
}