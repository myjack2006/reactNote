var path=require('path');

var config = {
	devtool: 'cheap-module-eval-source-map',
    entry: './main.js',
    output: {
        path: path.join(__dirname,'./dist/js'),
        filename: 'index.js',
    },
    devServer: {
        inline: true,
        port: 7777
    },
    module: {
        rules: [{
            test: /.jsx?$/,
            loader:'babel',
            include:path.resolve(__dirname,'src'),
            exclude:path.resolve(__dirname,'node_modules'),
            query: {
                presets: ['es2015', 'react']
            }
        }]
    }
}
module.exports = config;